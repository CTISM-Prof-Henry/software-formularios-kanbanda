from django.apps import AppConfig

class OrganizacionalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'organizacional'
    verbose_name = 'Estrutura Organizacional'
