# GR·UFSM — Sistema de Gestão de Riscos Institucionais

Sistema web Django para identificação, análise e tratamento de riscos da **Universidade Federal de Santa Maria**, seguindo padrões de sistemas institucionais federais: RBAC, soft delete, auditoria, sem cadastro público, ativação por token.

---

## Stack

| Camada | Tecnologia |
|---|---|
| Backend | Python 3.10+ · Django 4.2 |
| Banco | PostgreSQL (produção) · SQLite (desenvolvimento) |
| Frontend | HTML5 · Bootstrap 5 (CDN) · JavaScript vanilla |
| Auditoria | django-simple-history |
| Auth | Backend customizado (matrícula ou e-mail) |

---

## Estrutura do Projeto

```
risco_ufsm/
├── accounts/               ← autenticação, usuários, tokens, RBAC
│   ├── models.py           ← Usuario, TokenAtivacao, TokenRecuperacao, LogAcesso, TentativaLogin
│   ├── backends.py         ← login por matrícula OU e-mail
│   ├── middleware.py       ← sessão expirada (30min) + brute force
│   ├── decorators.py       ← @requer_perfil, @requer_admin, etc.
│   ├── services.py         ← criação de tokens, envio de e-mail, auditoria
│   ├── validators.py       ← SenhaForteValidator (maiúscula+número+especial)
│   ├── views.py            ← login, logout, ativação, recuperação, CRUD usuários
│   └── management/
│       └── commands/
│           └── criar_admin_inicial.py
├── organizacional/         ← Unidade, Setor, UsuarioSetor (soft delete + histórico)
├── auditoria/              ← LogAlteracao (imutável)
├── templates/
│   ├── base_auth.html      ← layout público (login, ativação, recuperação)
│   ├── base_sistema.html   ← layout autenticado (topbar + sidebar dinâmica)
│   └── accounts/           ← todas as telas do módulo
└── risco_ufsm/             ← configurações Django
```

---

## Instalação Rápida

```bash
# 1. Clone / extraia o projeto
cd risco_ufsm

# 2. Execute o script de setup
chmod +x setup.sh && ./setup.sh

# 3. Inicie o servidor
source venv/bin/activate
USE_SQLITE=true python manage.py runserver
```

Acesse: **http://localhost:8000/login/**

---

## Instalação Manual (PostgreSQL)

```bash
# Criar banco
createdb risco_ufsm

# Instalar dependências
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Migrations
python manage.py migrate

# Criar primeiro administrador
python manage.py criar_admin_inicial

# Rodar
python manage.py runserver
```

---

## Usuários de Teste (após `setup.sh` com dados de exemplo)

| Matrícula | Senha | Perfil |
|---|---|---|
| `0000001` | `Admin@123` | Administrador do Sistema |
| `9990001` | `Gestor@123` | Gestor da Unidade |
| `9990002` | `Setor@1234` | Gestor de Setor |
| `9990003` | `Serv@12345` | Servidor / Colaborador |

---

## Perfis e Permissões

| Funcionalidade | Admin | G. Unidade | G. Setor | Servidor |
|---|:---:|:---:|:---:|:---:|
| Criar usuários | ✅ | ✅* | ❌ | ❌ |
| Editar usuários | ✅ | ✅* | ✅** | ❌ |
| Ativar/desativar | ✅ | ✅* | ❌ | ❌ |
| Listar usuários | ✅ | ✅* | ✅** | ❌ |
| Logs de acesso | ✅ | ❌ | ❌ | ❌ |
| Meu perfil / senha | ✅ | ✅ | ✅ | ✅ |
| Painel | ✅ | ✅ | ✅ | ✅ |

\* Restrito à própria unidade. Admin não pode ser criado/editado por Gestor Unidade.  
\*\* Restrito ao próprio setor. Sem alterar perfil ou status.

---

## Fluxo de Cadastro (sem acesso público)

```
Admin/Gestor cria usuário
        ↓
Sistema envia e-mail com link único (token UUID, 48h)
        ↓
Usuário clica no link → cria senha (8+ chars, maiúscula, minúscula, número, especial)
        ↓
Conta ativada → pode fazer login
```

---

## Segurança Implementada

- **Senhas criptografadas** (PBKDF2 + SHA256, Django padrão)
- **CSRF** em todos os formulários POST
- **Sessão** expira em 30 minutos de inatividade
- **Brute force**: bloqueia IP após 5 tentativas falhas por 15 minutos
- **Token de ativação**: UUID v4, expira em 48h, uso único
- **Token de recuperação**: UUID v4, expira em 15 minutos, uso único
- **Nunca revela** se usuário existe na recuperação de senha
- **Soft delete**: nenhum registro é apagado fisicamente
- **Logs imutáveis**: LogAcesso e LogAlteracao bloqueiam `.delete()`
- **Histórico completo** via `django-simple-history` em Usuario, Unidade, Setor, UsuarioSetor
- **Scoping organizacional**: cada perfil vê apenas os dados do seu escopo

---

## Configuração de E-mail

Em desenvolvimento (padrão), os e-mails são impressos no terminal (`console`).  
Para produção, edite o `.env`:

```env
EMAIL_BACKEND=smtp
EMAIL_HOST=smtp.ufsm.br
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=noreply@ufsm.br
EMAIL_HOST_PASSWORD=sua_senha
DEFAULT_FROM_EMAIL=GR-UFSM <noreply@ufsm.br>
```

---

## URLs Disponíveis

| URL | Acesso | Descrição |
|---|---|---|
| `/login/` | Público | Tela de login |
| `/recuperar-senha/` | Público | Solicitar redefinição |
| `/redefinir-senha/<token>/` | Token válido | Criar nova senha |
| `/ativar-conta/<token>/` | Token válido | Ativação inicial |
| `/painel/` | Autenticado | Painel por perfil |
| `/usuarios/` | Admin/G.Unidade/G.Setor | Listar usuários |
| `/usuarios/novo/` | Admin/G.Unidade | Cadastrar usuário |
| `/usuarios/<id>/editar/` | Conforme escopo | Editar usuário |
| `/usuarios/<id>/toggle-ativo/` | Admin/G.Unidade | Ativar/Desativar |
| `/usuarios/<id>/reenviar-ativacao/` | Admin/G.Unidade | Reenviar e-mail |
| `/meu-perfil/` | Autenticado | Dados pessoais e senha |
| `/logs/acesso/` | Admin | Auditoria de acessos |
| `/admin/` | Staff Django | Painel administrativo |

---

## Próximos Módulos

- [ ] RF03 — Formulário de Análise de Risco (Identificação / Avaliação / Tratamento)
- [ ] RF05 — Listagem de Formulários com filtros
- [ ] RF07 — Dashboard com Matriz de Risco
- [ ] RF09 — Exportação de relatórios PDF
- [ ] RF10 — Monitoramento e histórico de versões

---

## Contato

**diegobreis@ufsm.br**
