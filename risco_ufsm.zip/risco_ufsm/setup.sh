#!/usr/bin/env bash
# ============================================================
#  GR·UFSM — Script de Configuração
# ============================================================
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${CYAN}→ $1${NC}"; }
success() { echo -e "${GREEN}✔ $1${NC}"; }
warn()    { echo -e "${YELLOW}⚠ $1${NC}"; }
error()   { echo -e "${RED}✖ $1${NC}"; exit 1; }

echo ""
echo "RiskShield - UFSM — Configuração do Ambiente"
echo ""

# 1. Pré-requisitos
command -v python3 >/dev/null 2>&1 || error "Python3 não encontrado."
PYVER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
info "Python $PYVER detectado"

# 2. Ambiente virtual
if [ ! -d "venv" ]; then
    info "Criando ambiente virtual..."
    python3 -m venv venv
fi
source venv/bin/activate
success "Ambiente virtual ativado"

# 3. Dependências
info "Instalando dependências..."
pip install -q --upgrade pip
pip install -q -r requirements.txt
success "Dependências instaladas"

# 4. Banco de dados
echo ""
echo "Banco de dados:"
echo "  1) SQLite  — desenvolvimento local (sem configuração)"
echo "  2) PostgreSQL — produção"
read -rp "Opção [1/2, padrão=1]: " DB_OPT
DB_OPT=${DB_OPT:-1}

if [ "$DB_OPT" = "2" ]; then
    read -rp "  Nome do banco [risco_ufsm]: "  DB_NAME;  DB_NAME=${DB_NAME:-risco_ufsm}
    read -rp "  Usuário [postgres]: "           DB_USER;  DB_USER=${DB_USER:-postgres}
    read -rsp "  Senha: "                        DB_PASS;  echo
    read -rp "  Host [localhost]: "             DB_HOST;  DB_HOST=${DB_HOST:-localhost}
    read -rp "  Porta [5432]: "                 DB_PORT;  DB_PORT=${DB_PORT:-5432}

    # Gera .env
    cat > .env <<EOF
USE_SQLITE=false
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASS
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DEBUG=True
EMAIL_BACKEND=console
EOF
    info "Rodando migrations no PostgreSQL..."
    python manage.py migrate
else
    echo "USE_SQLITE=true" > .env
    echo "DEBUG=True"      >> .env
    echo "EMAIL_BACKEND=console" >> .env
    info "Rodando migrations no SQLite..."
    USE_SQLITE=true python manage.py migrate
fi
success "Banco de dados configurado"

# 5. Criar administrador inicial
echo ""
read -rp "Criar o administrador inicial agora? [S/n]: " CREATE_ADMIN
CREATE_ADMIN=${CREATE_ADMIN:-S}

if [[ "$CREATE_ADMIN" =~ ^[Ss]$ ]]; then
    if [ "$DB_OPT" = "2" ]; then
        python manage.py criar_admin_inicial
    else
        USE_SQLITE=true python manage.py criar_admin_inicial
    fi
fi

# 6. Dados de exemplo
echo ""
read -rp "Carregar dados de exemplo (unidades, setores, usuários de teste)? [s/N]: " LOAD_DEMO
if [[ "$LOAD_DEMO" =~ ^[Ss]$ ]]; then
    CMD="python manage.py shell"
    [ "$DB_OPT" != "2" ] && CMD="USE_SQLITE=true $CMD"
    eval $CMD -c "
from organizacional.models import Unidade, Setor
from accounts.models import Usuario, Perfil
from organizacional.models import UsuarioSetor

u1 = Unidade.objects.get_or_create(sigla='CT',      defaults=dict(nome='Centro de Tecnologia', tipo='CENTRO'))[0]
u2 = Unidade.objects.get_or_create(sigla='PROGRAD', defaults=dict(nome='Pró-Reitoria de Graduação', tipo='PRO_REITORIA'))[0]
s1 = Setor.objects.get_or_create(sigla='DAINF', unidade=u1, defaults=dict(nome='Departamento de Informática'))[0]
s2 = Setor.objects.get_or_create(sigla='CENS',  unidade=u2, defaults=dict(nome='Coordenadoria de Ensino'))[0]

for mat, email, fn, sn, pf, pw, setor in [
    ('9990001','gu@ufsm.br','Maria','Silva',  Perfil.GESTOR_UNIDADE,'Gestor@123', s2),
    ('9990002','gs@ufsm.br','João', 'Souza',  Perfil.GESTOR_SETOR,  'Setor@1234', s1),
    ('9990003','sv@ufsm.br','Ana',  'Costa',  Perfil.SERVIDOR,      'Serv@12345', s1),
]:
    if not Usuario.objects.filter(matricula=mat).exists():
        u = Usuario.objects.create_user(mat,email,fn,sn,perfil=pf,conta_ativada=True)
        u.set_password(pw); u.save()
        UsuarioSetor.objects.create(usuario=u, setor=setor, ativo=True)
        print(f'  Criado: {fn} {sn} ({pf}) — mat={mat} / senha={pw}')
"
    success "Dados de exemplo carregados"
fi

# 7. Resumo
echo ""
echo "Configuração concluída!"
echo ""
echo "Para iniciar o servidor:"
if [ "$DB_OPT" = "2" ]; then
    echo "  source venv/bin/activate && python manage.py runserver"
else
    echo "  source venv/bin/activate && USE_SQLITE=true python manage.py runserver"
fi
echo ""
echo "Acesse: http://127.0.0.1:8000/login/"
echo "Admin Django: http://127.0.0.1:8000/admin/"
echo ""
